//
//  UserDetail+CoreDataProperties.swift
//  Core Data
//
//  Created by Ashish on 25/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

import Foundation
import CoreData


extension UserDetail {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<UserDetail> {
        return NSFetchRequest<UserDetail>(entityName: "UserDetail");
    }

    @NSManaged public var dob: String?
    @NSManaged public var email: String?
    @NSManaged public var name: String?
    @NSManaged public var userName: String?
    @NSManaged public var age: String?

}
