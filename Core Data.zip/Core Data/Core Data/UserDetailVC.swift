//
//  ViewController.swift
//  Core Data
//
//  Created by Ashish on 24/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

import UIKit
import CoreData

class UserDetailVC: UIViewController {
    
    var dbAccess = DBAccess()
    
    
    //    MARK: Outlets
    //    =================
    @IBOutlet weak var userTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("userdetail: \(dbAccess.userdetail)")
        
        //     MARK: Register the Nib File
        //     =============================
        let cellNib = UINib(nibName: "TableViewCell", bundle: nil)
        userTableView.register(cellNib, forCellReuseIdentifier: "UserTableViewCellID")
        
        self.userTableView.dataSource = self
        self.userTableView.delegate = self
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        dbAccess.fetchData()
        userTableView.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //    MARK: Actions
    //    ================
    
    @IBAction func nextBtn(_ sender: UIBarButtonItem) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let EditUserDetailsScene = storyboard.instantiateViewController(withIdentifier: "EditUserDetailsVC")
        
        navigationController?.pushViewController(EditUserDetailsScene, animated: true)
        
    }
}

//        MARK: UITableView DataSource And Delegate Methods
//        ===================================================

extension UserDetailVC : UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return  dbAccess.userdetail.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "UserTableViewCellID", for: indexPath) as? UserTableViewCell else {
            
            fatalError("Cell Not Found !")
        }
        cell.userDetailTextField.borderStyle = UITextBorderStyle.none
        cell.userDetailTextField.isEnabled = false
        
        switch indexPath.row {
            
        case 0 : cell.userDetailTextField.text = dbAccess.userdetail[0].name
        case 1 : cell.userDetailTextField.text = dbAccess.userdetail[0].age
        case 2 : cell.userDetailTextField.text = dbAccess.userdetail[0].userName
        case 3 : cell.userDetailTextField.text = dbAccess.userdetail[0].dob
        case 4 : cell.userDetailTextField.text = dbAccess.userdetail[0].email
            
        default:
            break
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        let deleteButton = UITableViewRowAction(style: .default, title: "Delete") { (UITableViewRowAction, IndexPath) in
            
            self.dbAccess.deleteData(index: indexPath)
            tableView.deleteRows(at: [indexPath], with: .fade)
              self.dbAccess.savedetail()
            self.userTableView.reloadData()
            
        }
        
        let editButton = UITableViewRowAction(style: .default, title: "Edit") { (UITableViewRowAction, IndexPath) in
            
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            
            guard let editUserDetailsScene = storyBoard.instantiateViewController(withIdentifier: "") as? EditUserDetailsVC else {
                
                fatalError("EditUserDetailsVC not found !")
            }
            self.navigationController?.pushViewController(editUserDetailsScene, animated: true)
            
        }
        
        return [editButton, deleteButton]
    }
}

