//
//  ViewController.swift
//  Core Data
//
//  Created by Ashish on 24/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

import UIKit
import CoreData

class UserDetailVC: UIViewController {
    
    var dbAccess = DBAccess()
    var cellTap : Bool = false

    //    MARK: Outlets
    //    =================
    
    @IBOutlet weak var userTableView: UITableView!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("userdetail: \(dbAccess.userdetail)")
        
        //     MARK: Register the Nib File
        //     =============================
        let cellNib = UINib(nibName: "TableViewCell", bundle: nil)
        userTableView.register(cellNib, forCellReuseIdentifier: "UserTableViewCellID")
        
        self.userTableView.dataSource = self
        self.userTableView.delegate = self
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        dbAccess.fetchData()
        userTableView.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //    MARK: Actions
    //    ================
    
    @IBAction func nextBtn(_ sender: UIBarButtonItem) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let EditUserDetailsScene = storyboard.instantiateViewController(withIdentifier: "EditUserDetailsVC")
        
        navigationController?.pushViewController(EditUserDetailsScene, animated: true)
        
    }
}

//        MARK: UITableView DataSource And Delegate Methods
//        ===================================================

extension UserDetailVC : UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return  dbAccess.userdetail.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "UserTableViewCellID", for: indexPath) as? UserTableViewCell else {
            
            fatalError("Cell Not Found !")
        }
        cell.userDetailTextField.borderStyle = UITextBorderStyle.none
        cell.userDetailTextField.isEnabled = false
        cell.userDetailLabel.isHidden = true
        cell.userDetailTextField.text = dbAccess.userdetail[indexPath.row].name
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        let deleteButton = UITableViewRowAction(style: .default, title: "Delete") { (UITableViewRowAction, IndexPath) in
            
            self.dbAccess.deleteData(index: indexPath)
            tableView.deleteRows(at: [indexPath], with: .fade)
            self.dbAccess.savedetail()
            self.userTableView.reloadData()
            
        }
        
        let editButton = UITableViewRowAction(style: .default, title: "Edit") { (UITableViewRowAction, IndexPath) in
            
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            
            guard let editUserDetailsScene = storyBoard.instantiateViewController(withIdentifier: "EditUserDetailsVC") as? EditUserDetailsVC else {
                
                fatalError("EditUserDetailsVC not found !")
            }
            editUserDetailsScene.cellTap = true
            editUserDetailsScene.indexx = indexPath.row
            editUserDetailsScene.previewData = self.dbAccess.userdetail[indexPath.row]
            self.navigationController?.pushViewController(editUserDetailsScene, animated: true)
            
        }
        return [editButton, deleteButton]
    }
}

