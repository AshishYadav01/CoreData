//
//  EditUserDetailsVC.swift
//  Core Data
//
//  Created by Ashish on 24/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

import UIKit
import CoreData

class EditUserDetailsVC: UIViewController {

    var indexx : Int = 0
    let dbAccess = DBAccess()
    var cellTap : Bool = false
    var previewData : UserDetail?
    var userDetailLabel = ["Name", "Username", "Email", "Age", "DOB"]
    
//    MARK: Outlets
//    ================
    @IBOutlet weak var EditUserDetailsTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let nib = UINib(nibName: "TableViewCell", bundle: nil)
        EditUserDetailsTableView.register(nib, forCellReuseIdentifier: "UserTableViewCellID")

        self.EditUserDetailsTableView.dataSource  = self
        self.EditUserDetailsTableView.delegate = self
        
        title = "Edit User Details"
        
//        MARK: UINavigationBar Button
//        ==============================
        
        let addBtn = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(saveDataBtn(_:)))
        self.navigationItem.rightBarButtonItem = addBtn
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        dbAccess.fetchData()
        EditUserDetailsTableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//    MARK: UINavigationBar Button Actions
//    ====================================
    func saveDataBtn(_ sender: UIBarButtonItem) {
        
        if self.cellTap == true {
            dbAccess.updateData(index: self.indexx, data: dbAccess.userDetailDictionary)
        }
        else {
            dbAccess.savedetail()
        }
        navigationController?.popToRootViewController(animated: true)
    }
}

//    MARK: UITableViewDataSource
//    =============================
extension EditUserDetailsVC : UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 5
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 64 
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "UserTableViewCellID", for: indexPath) as? UserTableViewCell else {
            
            fatalError("Cell not Found !")
        }
        cell.userDetailTextField.delegate = self
        cell.userDetailLabel.text = self.userDetailLabel[indexPath.row]
        cell.userDetailTextField.placeholder = self.userDetailLabel[indexPath.row]
        if cellTap == true {
            switch indexPath.row {
            case 0: cell.userDetailTextField.text = self.previewData?.name
            case 1: cell.userDetailTextField.text = self.previewData?.userName
            case 2: cell.userDetailTextField.text = self.previewData?.email
            case 3: cell.userDetailTextField.text = self.previewData?.age
            case 4: cell.userDetailTextField.text = self.previewData?.dob
            default:
                break
            }
        }
        return cell
    }
}

//       MARK: UITextFieldDelegate Methods
//       ===================================
extension EditUserDetailsVC : UITextFieldDelegate {
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        guard let point = textField.superview?.convert(textField.frame.origin, to: EditUserDetailsTableView) else{fatalError("textField Point is not Found")}
        let indexPath = EditUserDetailsTableView.indexPathForRow(at: point)

            switch indexPath!.row {
            case 0: dbAccess.userDetailDictionary["name"] = textField.text
            case 1: dbAccess.userDetailDictionary["username"] = textField.text
            case 2: dbAccess.userDetailDictionary["email"] = textField.text
            case 3: dbAccess.userDetailDictionary["age"] = textField.text
            case 4: dbAccess.userDetailDictionary["dob"] = textField.text
            default: break
        }
    }
}
