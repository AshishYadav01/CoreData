//
//  EditUserDetailsVC.swift
//  Core Data
//
//  Created by Ashish on 24/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

import UIKit
import CoreData

class EditUserDetailsVC: UIViewController {

    let dbAccess = DBAccess()
    
//    MARK: Outlets
//    ================
    @IBOutlet weak var EditUserDetailsTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let nib = UINib(nibName: "TableViewCell", bundle: nil)
        EditUserDetailsTableView.register(nib, forCellReuseIdentifier: "UserTableViewCellID")

        self.EditUserDetailsTableView.dataSource  = self
        self.EditUserDetailsTableView.delegate = self
        
        title = "Edit User Details"
        
//        MARK: UINavigationBar Button
//        ==============================
        
        let addBtn = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(saveDataBtn(_:)))
        self.navigationItem.rightBarButtonItem = addBtn
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//    MARK: UINavigationBar Button Actions
//    ====================================
    func saveDataBtn(_ sender: UIBarButtonItem) {
        
        dbAccess.savedetail()
        navigationController?.popToRootViewController(animated: true)
        
    }
}

//    MARK: UITableViewDataSource
//    =============================
extension EditUserDetailsVC : UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "UserTableViewCellID", for: indexPath) as? UserTableViewCell else {
            
            fatalError("Cell not Found !")
        }
        
        cell.userDetailTextField.delegate = self
        return cell
    }
    }

//       MARK: UITextFieldDelegate Methods
//       ===================================
extension EditUserDetailsVC : UITextFieldDelegate {
    
    func textFieldDidEndEditing(_ textField: UITextField) {
       
        guard let point = textField.superview?.convert(textField.frame.origin, to: EditUserDetailsTableView) else{fatalError("textField Point is not Found")}
        let indexPath = EditUserDetailsTableView.indexPathForRow(at: point)
        
        switch indexPath!.row {
        case 0: dbAccess.name = textField.text
        case 1: dbAccess.email = textField.text
        case 2: dbAccess.userName = textField.text
        case 3: dbAccess.age = textField.text
        case 4: dbAccess.dob = textField.text
        default:
            break
        }
        
    }

}
