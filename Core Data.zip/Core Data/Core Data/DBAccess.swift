//
//  File.swift
//  Core Data
//
//  Created by Ashish on 25/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class DBAccess{
    
    var userdetail = [UserDetail]()
    
    var userDetailDictionary : [String : String] = ["name" : "",
                                   "username" : "",
                                   "email" : "",
                                   "age" : "",
                                   "dob" : ""
    ]
    
    
//    MARK: Save Data in the DB
//    ===========================
    func savedetail() {
        
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else {return}
        
        let managedContext = delegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "UserDetail", in: managedContext)
        let person = UserDetail(entity: entity!, insertInto: managedContext)
        
        person.name = userDetailDictionary["name"]
        person.email = userDetailDictionary["username"]
        person.userName = userDetailDictionary["email"]
        person.age = userDetailDictionary["age"]
        person.dob = userDetailDictionary["dob"]
        
        do {
            try managedContext.save()
            userdetail.append(person)
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
//    MARK: fetch data from the DB
//    ==============================
    func fetchData(){
        
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else {return}
        
        let managedContext = delegate.persistentContainer.viewContext
        let fetchReguest : NSFetchRequest<UserDetail> = UserDetail.fetchRequest()
        
        do {userdetail = try managedContext.fetch(fetchReguest)
        print("userdetail: \(userdetail)")
        }
        
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    
//    MARK: delete data from the DB
//    ==============================
    func deleteData(index : IndexPath){
        
        guard let appdelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let managedContext = appdelegate.persistentContainer.viewContext
        managedContext.delete(userdetail[index.row])
        userdetail.remove(at: index.row)
        
    }
    
//    MARK: Update data in the DB
//    =============================
    func updateData(index : Int, data : [String : String]) {
        
       guard let appdelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        print("data:\(data)")
        userdetail[index].name = data["name"]
        userdetail[index].userName = data["username"]
        userdetail[index].email = data["email"]
        userdetail[index].age = data["age"]
        userdetail[index].dob = data["dob"]
        appdelegate.saveContext()
        
    }
}
