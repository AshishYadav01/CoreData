//
//  File.swift
//  Core Data
//
//  Created by Ashish on 25/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class DBAccess{
    
    var userdetail = [UserDetail]()
    
    var name : String?
    var email : String?
    var userName : String?
    var age : String?
    var dob : String?
    
    
//    MARK: Save Data in the DB
//    ===========================
    func savedetail() {
        
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else {return}
        
        let managedContext = delegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "UserDetail", in: managedContext)
        let person = UserDetail(entity: entity!, insertInto: managedContext)
        
        person.name = name
        person.email = email
        person.userName = userName
        person.age = age
        person.dob = dob
        print("person: \(person)")
        
        do {
            try managedContext.save()
            userdetail.append(person)
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
        print("Array: \(userdetail)")
    }
    
//    MARK: fetch data from the DB
//    ==============================
    func fetchData(){
        
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else {return}
        
        let managedContext = delegate.persistentContainer.viewContext
        let fetchReguest : NSFetchRequest<UserDetail> = UserDetail.fetchRequest()
        
        do {userdetail = try managedContext.fetch(fetchReguest)}
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    
//    MARK: delete data from the DB
//    ==============================
    func deleteData(index : IndexPath){
        
        guard let appdelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let managedContext = appdelegate.persistentContainer.viewContext
        managedContext.delete(userdetail[index.row])
        userdetail.remove(at: index.row)
        
    }
    
//    MARK: Update data in the DB
//    =============================
//    func updateData(index : Int, data : String) {
//        
//       guard let appdelegate = UIApplication.shared.delegate as? AppDelegate else {return}
//       
//        
//        
//    }
    
}
