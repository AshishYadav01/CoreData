//
//  TableViewCell.swift
//  Core Data
//
//  Created by Ashish on 24/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

import UIKit

class UserTableViewCell: UITableViewCell {

//    MARK: Outlets
//    ===============
    
    @IBOutlet weak var userDetailLabel: UILabel!
    
    @IBOutlet weak var userDetailTextField: UITextField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
