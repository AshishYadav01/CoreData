//
//  UserDetail+CoreDataClass.swift
//  Core Data
//
//  Created by Ashish on 25/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

import Foundation
import CoreData


public class UserDetail: NSManagedObject {

}
